package com.example.qlcuahangtaphoa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class DonHangActivity extends AppCompatActivity {

    ImageButton btnBack, btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_don_hang);
        btnBack =(ImageButton) findViewById(R.id.btnBack);
        btnAdd = (ImageButton) findViewById(R.id.btnAdd);

        updateAppbar();
    }
    public void updateAppbar(){
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}