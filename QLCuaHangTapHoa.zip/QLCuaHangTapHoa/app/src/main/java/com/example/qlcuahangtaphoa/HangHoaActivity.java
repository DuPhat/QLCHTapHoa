package com.example.qlcuahangtaphoa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class HangHoaActivity extends AppCompatActivity {

    ImageButton btnBack, btnAdd, btnMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hang_hoa);
        btnBack =(ImageButton) findViewById(R.id.btnBack);
        btnAdd = (ImageButton) findViewById(R.id.btnAdd);
        btnMenu = (ImageButton) findViewById(R.id.btnMenu);
        updateAppbar();
    }
    public void updateAppbar(){
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}